<img align="center" height="260" src="http://www.weebly.com/uploads/2/4/3/9/24397769/1986986_orig.png">
Invoke Demo
======

Purpose - Demos some Simple Use Cases of the LISA Invoke REST API.

LISA Invoke Demonstration PostMan (Rest Client for Chrome) Project to get PostMan https://chrome.google.com/webstore/detail/postman-rest-client/fdmmgilgnpjigdojojpjoooidkmcomcm?hl=en

This project requires the following Pre-Requisites:

Services Must be started before running:
Registry
VSE
Coordinator
Simulator
Web Console

Mar Files:
All Tests Suite https://github.com/ianakelly/Invoke/blob/master/AllTestsSuite.mar
Kiosk V6 https://github.com/ianakelly/Invoke/blob/master/kioskV6.mar
SOAP Request/Response Pairs https://github.com/ianakelly/Invoke/blob/master/soapRRs.zip

PostMan Collection:
https://github.com/ianakelly/Invoke/blob/master/Invoke%20Collection.json

LISA Bank ATM GUI Example - Used to validate Virtual Service post Deploy
Kiosk V6 Mar file
All Test Suite from Examples Project Mar'd
Demo Server should be running

The Demonstration Script is as follows:

Swagger URL http://localhost:1505/api/swagger/


http://localhost:1505/api/swagger/
